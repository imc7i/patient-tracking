
document.getElementById('patient-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const date = document.getElementById('admission-date').value;

    const entry = document.createElement('li');
    entry.textContent = `المريض ${name} - تاريخ الدخول: ${date}`;
    document.getElementById('patient-list').appendChild(entry);

    alert('تم الحفظ. سيتم تذكيرك باليوم الثاني والخامس (تلقائياً لاحقاً).');
});
