document.getElementById('patientForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const room = document.getElementById('room').value;
  const mrn = document.getElementById('mrn').value;
  const admissionDate = new Date(document.getElementById('admissionDate').value);
  const notes = document.getElementById('notes').value;

  const day2 = new Date(admissionDate);
  const day5 = new Date(admissionDate);
  day2.setDate(day2.getDate() + 1);
  day5.setDate(day5.getDate() + 4);

  const table = document.querySelector('#patientsTable tbody');
  const row = table.insertRow();
  row.innerHTML = `
    <td>${room}</td>
    <td>${mrn}</td>
    <td>${admissionDate.toLocaleDateString('ar-EG')}</td>
    <td>${day2.toLocaleDateString('ar-EG')}</td>
    <td>${day5.toLocaleDateString('ar-EG')}</td>
    <td>${notes}</td>
  `;

  // Clear form
  document.getElementById('patientForm').reset();
});
